#ifndef NUMBER_CONSTANTS_H
#define NUMBER_CONSTANTS_H

#include "Number.h"
const Number one = Number(1.0);
const Number zero = Number(0.0);

#endif //NUMBER_CONSTANTS_H