#pragma once

#include "NumberLib.h"
const Number one = Number(1.0);
const Number zero = Number(0.0);