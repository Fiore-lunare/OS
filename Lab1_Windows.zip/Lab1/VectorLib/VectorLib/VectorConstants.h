#pragma once
#include "VectorLib.h"

extern VECTORLIB_API const Vector vector_one;
extern VECTORLIB_API const Vector vector_zero;