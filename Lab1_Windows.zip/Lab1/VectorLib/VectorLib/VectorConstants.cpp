#include "VectorConstants.h"
#include "NumberConstants.h"

const Vector vector_one(one, one);
const Vector vector_zero(zero, zero);